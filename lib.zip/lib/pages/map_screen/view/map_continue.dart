import 'package:flutter/material.dart';
import 'package:flutter/src/widgets/container.dart';
import 'package:flutter/src/widgets/framework.dart';

class MapContinue extends StatefulWidget {
  const MapContinue({super.key});

  @override
  State<MapContinue> createState() => _MapContinueState();
}

class _MapContinueState extends State<MapContinue> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(),

      body: Stack(
        children: [

        ],
      ),
    );
  }
}