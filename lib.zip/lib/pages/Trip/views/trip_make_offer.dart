import 'package:flutter/material.dart';

class TripMakeOffer extends StatefulWidget {
  const TripMakeOffer({super.key});

  @override
  State<TripMakeOffer> createState() => _TripMakeOfferState();
}

class _TripMakeOfferState extends State<TripMakeOffer> {
  @override
  Widget build(BuildContext context) {
    return  SafeArea(child: Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          
        ],
      ),
    ),);

  }
}