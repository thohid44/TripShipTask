


const String baseUrl = 'https://app.tripshiptask.com/api/';

const String urlWithOutslash = 'https://app.tripshiptask.com/api';


//const String baseUrl = 'https://thecodegiant.xyz/api/'; 
//const String urlWithOutslash = 'https://thecodegiant.xyz/api'; 

const String registration = "/auth/signup";
