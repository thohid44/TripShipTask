class AppConstants {
  static const String appName = "TripShipTask";
  static const String baseUrl = "https://app.tripshiptask.com/api/"; 
 static const dynamic textSize1 = 12;
  // Trip End Points


  // Ship End Points

  // Task End Points

  
}
