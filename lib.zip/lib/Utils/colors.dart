import 'package:flutter/material.dart';

const Color primaryColor1 = Color(0xffFEFEFD);
const Color fillColor = Color(0xffF6EAE3);
const Color primaryColor = Color(0xffF1F4F9);
const Color navyBlueColor = Color(0xff5C67AE);
const Color skyColor = Color(0xff537FBD);
const Color purpuleColor = Color(0xff725DA6);
const Color tealColor = Color(0xff007A9D);
const Color lightNavyColor = Color(0xff9DA4CE);
const Color white = Colors.white;
const Color offWhite = Color(0xffF1F4F9);
const Color cameraColor = Color(0xffCED1E7);
const Color greenColor = Color(0xff00BC8B);
const Color purplColor = Color(0xff7a15f7);
