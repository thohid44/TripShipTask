class LocalStoreKey {
  static const token = "TOKEN";
  static const userId = "UserID";
  static const tripshiptaskId = "tripshiptaskID";
  static const fullName = "FullName";
  static const accountNo = "AccountName";

  static const logo = "Logo";
}
